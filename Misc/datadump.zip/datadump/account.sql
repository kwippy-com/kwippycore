/*
SQLyog Community Edition- MySQL GUI
Host - 5.0.21-community-nt 
*********************************************************************
Server version : 5.0.21-community-nt
*/
insert into `kwippy_account` (`id`, `user_id`, `name`, `provider`, `reg_type`, `created_at`) values('1','2','dhingra.mayank','1','1','2007-11-23 22:49:46');
insert into `kwippy_account` (`id`, `user_id`, `name`, `provider`, `reg_type`, `created_at`) values('2','3','k.a.anand@gmail.com','1','1','2007-11-25 13:10:48');
