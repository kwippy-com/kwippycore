/*
SQLyog Community Edition- MySQL GUI
Host - 5.0.21-community-nt 
*********************************************************************
Server version : 5.0.21-community-nt
*/
insert into `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) values('1','admin','','','dipankarsarkar@gmail.com','sha1$33f74$51cdf169d9a055eed7e494aa0f57467a413dddeb','1','1','1','2007-11-25 14:13:22','2007-11-22 11:21:02');
insert into `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) values('2','mayank','Mayank','Dhingra','dhingra.mayank@gmail.com','sha1$5b4fb$558839b0218c186b51e441ac71dc5935d60be339','1','1','1','2007-11-23 22:11:06','2007-11-23 22:11:06');
insert into `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) values('3','kaargocult','','','','sha1$72f74$a6341b84541882ae676642d6c106ad136345f6f1','0','1','0','2007-11-25 12:17:09','2007-11-25 12:17:09');
