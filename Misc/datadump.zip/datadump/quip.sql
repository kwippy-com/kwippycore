/*
SQLyog Community Edition- MySQL GUI
Host - 5.0.21-community-nt 
*********************************************************************
Server version : 5.0.21-community-nt
*/
insert into `kwippy_quip` (`id`, `user_id`, `text`, `source_type`, `quip_type`, `account_id`, `created_at`, `updated_at`) values('1','2','wtf','1','1','1','2007-11-23 22:56:32','2007-11-23 22:56:32');
insert into `kwippy_quip` (`id`, `user_id`, `text`, `source_type`, `quip_type`, `account_id`, `created_at`, `updated_at`) values('2','2','blah blah','1','1','1','2007-11-24 14:05:12','2007-11-24 14:05:12');
insert into `kwippy_quip` (`id`, `user_id`, `text`, `source_type`, `quip_type`, `account_id`, `created_at`, `updated_at`) values('3','3','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\" Lorem ipsum dolor seu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\" Lorem ipsum dolor s','2','1','2','2007-11-25 13:11:14','2007-11-25 13:11:14');
insert into `kwippy_quip` (`id`, `user_id`, `text`, `source_type`, `quip_type`, `account_id`, `created_at`, `updated_at`) values('4','3','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.','1','1','2','2007-11-25 13:11:44','2007-11-25 13:11:44');
