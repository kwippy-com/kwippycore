/*
SQLyog Community Edition- MySQL GUI
Host - 5.0.21-community-nt 
*********************************************************************
Server version : 5.0.21-community-nt
*/
insert into `kwippy_userprofile` (`id`, `login`, `picture`, `updated_at`, `about_me`, `gender`, `location_city`, `location_country`, `website`, `sexual`, `relation`, `user_id`) values('1','mayank','','2007-11-25 16:19:55','super hero','0','Delhi','India','http://s2c.com','0','25','2');
insert into `kwippy_userprofile` (`id`, `login`, `picture`, `updated_at`, `about_me`, `gender`, `location_city`, `location_country`, `website`, `sexual`, `relation`, `user_id`) values('2','addu','','2007-11-23 23:20:45','addu pachadu','0','adi','adi_land','http://addu.com','0','0','1');
insert into `kwippy_userprofile` (`id`, `login`, `picture`, `updated_at`, `about_me`, `gender`, `location_city`, `location_country`, `website`, `sexual`, `relation`, `user_id`) values('3','kaargocult','','2007-11-25 16:23:23','kaaaaaaaaaaa','1','DELHI','INDIA','http://kicksandkisses.blogspot.com','0','26','3');
